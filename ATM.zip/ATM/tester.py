from atm import accounts
from atm import transactions

acts = accounts.Accounts()

#acts.loadaccounts()

try:
    accountname = acts.validateaccountid('6')
    print "Valid Id : " + accountname

    if acts.validatepinnumber('5555'):
        print "Valid Pin number"


        #passing the amount and id
        #txn = transactions.Transactions()
        #txn.deposit(5)
        print "Log in id and password successful"
    else:
        print "Invalid Pin number"

except Exception as e:
    print "Error : " + e.message

del acts