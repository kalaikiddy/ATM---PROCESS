from datetime import datetime

class Transactions:

    filename = "./data/transation.csv"

    def __init__(self):
        self.amt = ""
        self.closingBalance = ""

    """def deposit(self, accountid, amount):
        with open(Transactions.filename, "w") as f:
            f.write("{no}, deposit, {amt}".format(no=accountid, amt=amount))"""

    def deposit(self, accountid):
        with open(Transactions.filename, "a") as f:
            f.write("hai")
            f.write("\n{aid} , Deposite".format(aid=accountid))



    def withdraw(self, accountid, amount):
        f1 = ""
        with open(Transactions.filename, "r") as f:
                print f.readlines()
                h = f.readlines()
                for onebyone in h:
                    print onebyone
                    fi = onebyone.split(",")
                    f1 = fi[0]
                    print f1

                if f1 != accountid:
                    print "insufficient"
                else:

                    with open(Transactions.filename, "a") as f:

                        todaydate = datetime.now().strftime("%d/%m/%y %X")
                        an = accountid
                        dt = todaydate
                        self.amt = amount

                        f.write("\n{},{},withdraw,{}".format(an, dt, self. amt))




    def listtransaction(self, accountid):
        self.closingBalance = 0
        with open(Transactions.filename, "r") as f:
            trans = []

            for line in f.readlines():
                fields = line.split(",")
                if fields[0] == accountid:
                    trans.append(line.strip())


        for l in trans:
            fields = l.split(",")
            id = fields[0]
            transdate = fields[1]
            transtype = fields[2]
            amount = float(fields[3])

        if id == accountid:
            print "your no available in transaction"
        else:
            print "your no not in transation"

            if transtype =='withdraw':
                amount = -amount
                if amount > self.closingBalance:
                    print "insufficient"
            self.closingBalance += amount

            #print #emptyline
            print "{},  {:<20s},  {:10.2f}".format(transdate, transtype, amount)


        print "Closing Balance %.2f" %self.closingBalance
