from atm import accounts
from atm import transactions

class ATMMenu:


    def __init__(self):
        #create the object
        self.acts = accounts.Accounts()
        self.txn = transactions.Transactions()

    def start(self):
        while True:
            print "------------------------"
            print "     Tamilnadu Bank     "
            print "------------------------"
            print
            ano = raw_input("Enter Account No :\n ")

            # verify account id
            try:
                account_name = self.acts.validateaccountid(ano)
                print "Account id  verified"
                print "Welcome %s" % account_name
                self.transactionMenu()

            except Exception as e:
                print "In valid Account no .,Press enter to continue.."
                raw_input()
                continue




    def transactionMenu(self):
        while True:
            print #emptyline
            print "Enter your choice"
            print "-----------------"
            print #emptyline
            print "1. Deposit Money"
            print "2. Withdraw Money"
            print "3. Transaction List"
            print "4. Exit and go back to account no entered"

            option = input("Enter the option :\n ")

            if option == 4:
                print "Exit from the menu"
                break

            elif option ==1:
                amount = raw_input("Enter the amount : ")
                self.newpincheckdepos(amount)

            elif option ==2:
                amount = raw_input("Enter the amount : ")
                self.newpincheckwith(amount)

            elif option ==3:
                self.newpincheckTrans()

            else:
                print "Enter valid no. Press Enter to continue.. "
                raw_input()
                continue

    def newpincheckTrans(self):
        print "Enter your pin number to Complete the Transaction."
        while True:
            print #emptyline

            pin = raw_input("Enter Pin : \n")
            validpin = self.acts.validatepinnumber(pin)
            if pin == validpin:
                print "Pin number verified"
                self.txn.listtransaction(self.acts.accountid)
                print "Transaction Completed"
                break

            else :
                print "Your Pin number is wrong. Please Try again.."
                continue

    def newpincheckwith(self,amount):
        while True:
            print "Enter your pin number to Complete the Transaction."
            pin = raw_input("Enter Pin : \n")
            validpin = self.acts.validatepinnumber(pin)

            if pin == validpin:
                try:
                    self.txn.withdraw(self.acts.accountid, amount)
                except Exception as e:
                    print "Error : " + e.message

                print "Transaction Completed"
                print  # emptyline
                print "Press enter to continue."
                raw_input()
                break

            else:
                print "Your Pin number is wrong. Please Try again.."
                continue

        print #emptyline

    def newpincheckdepos(self,amount):
        print "Enter your pin number to Complete the Transaction."
        while True:

            pin = raw_input("Enter Pin : \n")
            validpin = self.acts.validatepinnumber(pin)

            if pin == validpin:
                self.txn.deposit(self.acts.accountid, amount)
                print "Deposit Successfully. Press enter to continue.."
                print  # emptyline
                print "Transaction Completed"
                raw_input()
                break
            else:
                print "Your Pin number is wrong. Please Try again.."
                continue


















