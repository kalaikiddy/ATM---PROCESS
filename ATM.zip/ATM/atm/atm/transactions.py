from datetime import datetime

class Transactions:

    filename = "./data/trant.csv"

    def __init__(self):
        self.amt = ""
        self.closingBalance = 0
        self.transtype = 0
        self.minusvalue = 0

    def deposit(self, accountid, amount):
     with open(Transactions.filename, "a") as f:

            todaydate = datetime.now().strftime("%d/%m/%y %X")
            f.write("\n{an},{dt},deposit,{amt}".format(an=accountid,dt = todaydate, amt = amount ))



    def withdraw(self, accountid, at):


        if accountid == accountid:

            self.tt(accountid,at)


    def w(self,accountid, aa):

        print #emptyline

        with open(Transactions.filename, "a") as f:
                todaydate = datetime.now().strftime("%d/%m/%y %X")
                an = accountid
                dt = todaydate
                #self.amt = amount
                at = aa

                f.write("\n{},{},withdraw,{}".format(an, dt, at))
                print "your current process is success"



    def tt(self, accountid,amount):

            amt = amount

            with open(Transactions.filename, "r") as f:
                trans = []

                for line in f.readlines():
                    fields = line.split(",")
                    if fields[0] == accountid:
                        trans.append(line.strip())

            for l in trans:
                fields = l.split(",")
                transdate = fields[1]
                self.transtype = fields[2]

                amount = float(fields[3])


            if self.transtype == 'deposit':
                print



                self.minusvalue = amount - float (amt)

                print " yes , withdraw your balance "


                self.w(accountid, amt)

            else:
                print "Insufficient Balance"





    def listtransaction(self, accountid):
        self.closingBalance = 0

        with open(Transactions.filename, "r") as f:
            trans = []

            for line in f.readlines():
                fields = line.split(",")
                if fields[0] == accountid:
                    trans.append(line.strip())

        for l in trans:
            fields = l.split(",")
            transdate = fields[1]
            self.transtype = fields[2]
            amount = float(fields[3])

            if self.transtype =='withdraw':

                self.closingBalance -= amount
                amount = -amount
            if self.transtype =='deposit':

                self.closingBalance += amount



            print #emptyline
            print "{},  {:<20s},  {:10.2f}".format(transdate, self.transtype, amount)

        print "Closing Balance %.2f" %self.closingBalance