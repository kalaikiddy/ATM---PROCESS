#create constant variable
ACCOUNTNAME = 'NAME'
PINNUMBER = 'PIN'

#create class
class Accounts:

    #create static variable
    filename = "./data/accounts.csv"
    members = {}

    def __init__(self):
        self.accountid = ""
        if len(Accounts.members) == 0:
            self.loadaccounts()


    #open the file in functin


    def loadaccounts(self):

        #open the file
        with open(Accounts.filename, "r") as f:
            lines = f.readlines()


        print #emptyline
        #move the each rows in line variable
        for line in lines:
            if len(line) > 0:
                fields = line.split(",")


                print #emptyline
                accountid = fields[0].strip()
                accountname = fields[1].strip()
                pinnumber = fields[2].strip()

                Accounts.members[accountid] = {ACCOUNTNAME:accountname, PINNUMBER:pinnumber}
                print
        #print Accounts.members

    def validateaccountid(self, accountid):

        if Accounts.members.has_key(accountid):
            self.accountid = accountid  #To store the accountid for checking the pinnumber

            return Accounts.members[accountid][ACCOUNTNAME]


        else:
            raise Exception ("Invalid Account Id")

    def validatepinnumber(self, pinnumber):

        if Accounts.members.has_key(self.accountid):  #checking the pinumber by using accountid
            pin = Accounts.members[self.accountid][PINNUMBER]

            if pin == pinnumber:

                return Accounts.members[self.accountid][PINNUMBER]

        else:
            raise Exception ("Invalid Account Id")



