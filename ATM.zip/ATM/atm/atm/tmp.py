from datetime import datetime

class Transactions:

    filename = "./data/transaction.csv"

    def __init__(self):
        self.amt = ""
        self.closingBalance = 0
        self.transtype = 0

    def deposit(self, accountid, amount):



        with open(Transactions.filename, "a") as f:

            todaydate = datetime.now().strftime("%d/%m/%y %X")
            f.write("\n{an},{dt},deposit,{amt}".format(an=accountid,dt = todaydate, amt = amount ))
            print "successfully deposited you can now check the transaction file"