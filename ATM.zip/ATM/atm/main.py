from atm import menu

mnu = menu.ATMMenu()

mnu.start()

del mnu