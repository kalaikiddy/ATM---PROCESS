from atm import accounts
from atm import transactions

acts = accounts.Accounts()

#acts.loadaccounts()

try:
    accountname = acts.validateaccountid('5')
    print "Valid Id : " + accountname
    if acts.validatepinnumber('5555'):
        print "Valid Pin number"
        #passing the amount and id
        txn = transactions.Transactions()

        txn.withdraw(acts.accountid, 1)
        #txn.listtransaction(acts.accountid)
        print "Program processed successfully"
    else:
        print "Invalid Pin number"

except Exception as e:
    print "Error : " + e.message

del acts