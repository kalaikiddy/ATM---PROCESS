from atm import menu

mn = menu.ATMMenu()

mn.start()

del mn